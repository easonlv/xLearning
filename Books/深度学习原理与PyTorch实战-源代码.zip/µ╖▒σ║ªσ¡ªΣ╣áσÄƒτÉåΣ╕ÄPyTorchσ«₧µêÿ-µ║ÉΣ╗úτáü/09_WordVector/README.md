# book_DeepLearning_in_PyTorch_Source

词向量文件“vectors.bin”，约1.11G左右，请使用百度网盘下载：

链接:https://pan.baidu.com/s/1pMM0Z4B  密码:mg1p

